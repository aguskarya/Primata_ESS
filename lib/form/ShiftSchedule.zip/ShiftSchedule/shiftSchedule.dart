import 'package:flutter/material.dart';
import 'package:primata_ess/form/ShiftSchedule/DataTableSch.dart';
import 'package:primata_ess/model/view_TransJadwalShiftWeb.dart';
import 'package:primata_ess/services/viewTransJadwalShiftWeb_Schedule.dart';
import 'package:intl/intl.dart';

class ShiftSchedule extends StatefulWidget {
  const ShiftSchedule({Key? key}) : super(key: key);

  @override
  State<ShiftSchedule> createState() => _ShiftScheduleState();
}

class _ShiftScheduleState extends State<ShiftSchedule> {
  late List<ViewTransJadwalShiftWeb> shift;

  @override
  Widget build(BuildContext context) {
    getlistSchedule().then((value) {
      shift = value.toList();
      setState(() {});
    });

    return Scaffold(
        appBar: AppBar(
          title: const Text("Shift Schedule"),
          backgroundColor: Colors.teal[300],
        ),
        body: ListView(
          padding: const EdgeInsets.all(15),
          children: [
            const Padding(padding: EdgeInsets.only(top: 20.0)),
            Center(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      border: Border(
                        top: BorderSide(width: 1.0, color: Colors.black),
                        bottom: BorderSide(width: 1.0, color: Colors.black),
                        left: BorderSide(width: 1.0, color: Colors.black),
                        right: BorderSide(width: 1.0, color: Colors.black),
                      ),
                    ),
                    child: Center(
                      child: IconButton(
                        icon: const Icon(Icons.arrow_left),
                        onPressed: () {},
                        padding: const EdgeInsets.all(20.0),
                      ),
                    ),
                  ),
                  const Padding(padding: EdgeInsets.only(left: 20)),
                  Container(
                    child: const Center(
                        child: Text(
                      'Schedule',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    )),
                  ),
                  const Padding(padding: EdgeInsets.only(left: 20)),
                  Container(
                    decoration: const BoxDecoration(
                      border: Border(
                        top: BorderSide(width: 1.0, color: Colors.black),
                        bottom: BorderSide(width: 1.0, color: Colors.black),
                        left: BorderSide(width: 1.0, color: Colors.black),
                        right: BorderSide(width: 1.0, color: Colors.black),
                      ),
                    ),
                    child: const IconButton(
                      icon: Icon(Icons.arrow_right),
                      onPressed: null,
                      padding: EdgeInsets.all(20.0),
                    ),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: FutureBuilder<List<ViewTransJadwalShiftWeb>>(
                  future: getlistSchedule(),
                  builder: (BuildContext context,
                      AsyncSnapshot<List<ViewTransJadwalShiftWeb>> snapshot) {
                    if (!snapshot.hasData) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else {
                      return Container(
                        padding: const EdgeInsets.all(5),
                        child: DataTableSch(
                            datalist:
                                snapshot.data as List<ViewTransJadwalShiftWeb>),
                      );
                    }
                  }),
            ),
          ],
        ));
  }
}
