import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:primata_ess/model/view_TransJadwalShiftWeb.dart';

class DataTableSch extends StatelessWidget {
  DataTableSch({Key? key, required this.datalist}) : super(key: key);
  final List<ViewTransJadwalShiftWeb> datalist;

  final formatTgl = DateFormat('dd/MM/yyyy');
  final formatTime = DateFormat('hh:mm');
  final formatHari = DateFormat('EEEE');

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: FittedBox(
        child: DataTable(
          columns: const [
            DataColumn(
              label: Text('DATE',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.blue)),
              numeric: false,
            ),
            DataColumn(
              label: Text('SHIFT',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.blue)),
              numeric: false,
            ),
            DataColumn(
              label: Text('IN',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.blue)),
              numeric: false,
            ),
            DataColumn(
              label: Text('OUT',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.blue)),
              numeric: false,
            ),
            DataColumn(
              label: Text('TOTAL',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.blue)),
              numeric: false,
            ),
          ],
          rows: datalist
              .map((data) => DataRow(cells: [
                    DataCell(Column(
                      children: <Widget>[
                        Text(formatHari.format(DateTime?.parse(data.jabatan))),
                        Text(formatHari.format(DateTime?.parse(data.jabatan))),
                        Text(formatHari.format(DateTime?.parse(data.jabatan))),
                        Text(formatHari.format(DateTime?.parse(data.jabatan))),
                      ],
                    )),
                  ]))
              .toList(),
        ),
      ),
    );
  }
}
